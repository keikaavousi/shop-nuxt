export default () => ({
    cart:[]
})