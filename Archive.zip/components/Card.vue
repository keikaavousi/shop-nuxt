<template>
  <div class="col-md-3">
    <div class="card">
      <div class="card-top">
          <img src="/icon.png" class="card-img">
      </div>
      <div class="card-body">
          <h3>{{product.title}}</h3>
          <span>{{product.price}}$</span>
          <nuxt-link class="btn btn-light" :to="`/products/${product.id}`">View Details</nuxt-link>
          <button class="btn btn-info btn-block">Add to Cart</button>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
      name:'Card',
      props:{
        //['product']
        //product:Object
        product:{
            type:Object,
            required:true,
            //default
            // validator:function(value){
            //     return value>=0
            // }
        }
      },
    //   data(){
    //       return{
    //         myproduct:this.product
    //       }
    //   }
  }
</script>

<style scoped>
.card-body h3,.card-body span,.card-body a{
    display: block;
    margin-bottom: 10px;
}
</style>